# thrownforaloop

A package just to practice using Bash, pushing and pulling. The functions
contained are a small collection of sorting functions as well as a select group
of recursive functions that do things from give the nth term in a fibonacci
sequence to adding all values in an array.
